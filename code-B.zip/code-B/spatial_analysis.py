#!/usr/bin/env python3
# pip install -i https://pypi.tuna.tsinghua.edu.cn/simple geopandas==0.13.2 fiona==1.9.5 shapely==2.0.1 pyproj==3.5.0

import os
import glob
import logging
import pandas as pd
import numpy as np
import geopandas as gpd
from shapely.geometry import Point
import sys

# ==========================================================
# CONFIGURATION SECTION
# ==========================================================
# Base directory of the project
BASE_DIR = "."

# Input data directories
DATA_DIR = os.path.join(BASE_DIR, "data")
OPENAQ_DIR = glob.glob(os.path.join(DATA_DIR, "openaq_data_*"))[0]
TAXI_ZONE_DIR = os.path.join(DATA_DIR, "taxi_zones")

# Output directories
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
LOG_DIR = os.path.join(BASE_DIR, "logs")

# Path to shapefile (Taxi Zones)
SHAPEFILE_PATH = glob.glob(os.path.join(TAXI_ZONE_DIR, "*.shp"))[0]

# Spatial parameters
K_NEAREST = 3   # number of nearest stations
POWER = 2       # IDW power parameter

# Create directories if not exist
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# ==========================================================
# LOGGING SETUP
# ==========================================================
logging.basicConfig(
    filename=os.path.join(LOG_DIR, "spatial_analysis.log"),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Progress display function (dynamic terminal update)
def print_progress(prefix, current, total):
    percent = (current / total) * 100
    sys.stdout.write(f"\r{prefix}: {current}/{total} ({percent:.2f}%)")
    sys.stdout.flush()

print("Starting Spatial Analysis Pipeline...")
logging.info("Pipeline started")

# ==========================================================
# STEP 1: LOAD MONITORING STATIONS
# ==========================================================
print("\n[STEP 1] Loading monitoring stations...")

location_file = os.path.join(OPENAQ_DIR, "location_mapping.csv")
locations = pd.read_csv(location_file)

# Convert to GeoDataFrame with geometry
geometry = [Point(xy) for xy in zip(locations.longitude, locations.latitude)]
stations_gdf = gpd.GeoDataFrame(locations, geometry=geometry, crs="EPSG:4326")

logging.info(f"Loaded {len(stations_gdf)} monitoring stations")

# ==========================================================
# STEP 2: LOAD TAXI ZONES
# ==========================================================
print("[STEP 2] Loading taxi zones shapefile...")

zones = gpd.read_file(SHAPEFILE_PATH)

logging.info(f"Loaded {len(zones)} taxi zones")

# ==========================================================
# STEP 3: CRS TRANSFORMATION
# ==========================================================
print("[STEP 3] Transforming CRS to projected system (EPSG:2263)...")

# Transform both datasets to projected CRS for accurate distance calculation
zones = zones.to_crs(epsg=2263)
stations_gdf = stations_gdf.to_crs(epsg=2263)

logging.info("CRS transformed to EPSG:2263")

# ==========================================================
# STEP 4: COMPUTE CENTROIDS
# ==========================================================
print("[STEP 4] Computing zone centroids...")

# Use centroids to represent each zone
zones["centroid"] = zones.geometry.centroid
zones_centroids = zones.set_geometry("centroid")

# ==========================================================
# STEP 5: SPATIAL MATCHING (KNN + IDW)
# ==========================================================
print("[STEP 5] Performing spatial matching (KNN + IDW)...")

results = []
total_zones = len(zones_centroids)

# Loop through each zone
for idx, (_, zone) in enumerate(zones_centroids.iterrows(), 1):
    print_progress("Matching zones", idx, total_zones)

    zone_id = zone["LocationID"]
    zone_point = zone.geometry

    # Compute distances to all stations
    distances = stations_gdf.distance(zone_point)

    # Find K nearest stations
    nearest_idx = np.argsort(distances)[:K_NEAREST]
    nearest_distances = distances.iloc[nearest_idx]

    # Compute IDW weights
    weights = 1 / (nearest_distances ** POWER + 1e-6)
    weights = weights / weights.sum()

    # Store results
    for i, w in zip(nearest_idx, weights):
        results.append({
            "zone_id": zone_id,
            "station_id": stations_gdf.iloc[i]["location_id"],
            "distance_m": distances.iloc[i],
            "weight": w
        })

print()

# Save mapping
mapping_df = pd.DataFrame(results)
mapping_df.to_csv(os.path.join(OUTPUT_DIR, "zone_station_mapping.csv"), index=False)

logging.info("Spatial mapping completed")

# ==========================================================
# STEP 6: LOAD POLLUTION DATA
# ==========================================================
print("[STEP 6] Loading pollution data...")

pollution_files = glob.glob(os.path.join(OPENAQ_DIR, "**/*.csv"), recursive=True)

pollution_list = []
total_files = len(pollution_files)

# Read all pollution CSV files
for i, file in enumerate(pollution_files, 1):
    print_progress("Reading pollution files", i, total_files)

    if "location_mapping" in file:
        continue

    df = pd.read_csv(file)

    if df.empty:
        continue

    df = df[["datetime_hour", "location_id", "parameter", "value_mean"]]
    pollution_list.append(df)

print()

# Concatenate all data
pollution_df = pd.concat(pollution_list)

# Convert datetime format
pollution_df["datetime_hour"] = pd.to_datetime(
    pollution_df["datetime_hour"], format="%Y%m%d%H%M%S"
)

logging.info(f"Total pollution records: {len(pollution_df)}")

# ==========================================================
# STEP 7: SPATIO-TEMPORAL COMPUTATION (OPTIMIZED)
# ==========================================================
print("[STEP 7] Computing zone-level pollution (optimized)...")

zone_pollution = []

# -------- Optimization 1: Pre-group mapping --------
# Convert mapping to dictionary: zone -> (station_id, weight)
zone_mapping_dict = {
    zone_id: group[["station_id", "weight"]].values
    for zone_id, group in mapping_df.groupby("zone_id")
}

# -------- Optimization 2: Convert pollution data to dictionary --------
# Key: (time, parameter, station_id)
pollution_dict = {}

for _, row in pollution_df.iterrows():
    key = (row["datetime_hour"], row["parameter"], row["location_id"])
    pollution_dict[key] = row["value_mean"]

# Unique timestamps
unique_times = pollution_df["datetime_hour"].unique()
total_times = len(unique_times)

# -------- Main computation loop --------
for t_idx, t in enumerate(unique_times, 1):
    print_progress("Processing time steps", t_idx, total_times)

    # Filter once per time step
    df_time = pollution_df[pollution_df["datetime_hour"] == t]
    parameters = df_time["parameter"].unique()

    for zone_id, station_info in zone_mapping_dict.items():

        for param in parameters:
            total_value = 0
            has_value = False

            for station_id, weight in station_info:
                key = (t, param, station_id)

                # Fast lookup instead of DataFrame filtering
                if key in pollution_dict:
                    total_value += weight * pollution_dict[key]
                    has_value = True

            if has_value:
                zone_pollution.append({
                    "datetime": t,
                    "zone_id": zone_id,
                    "parameter": param,
                    "pollution": total_value
                })

print()

# Save results
zone_pollution_df = pd.DataFrame(zone_pollution)
zone_pollution_df.to_csv(
    os.path.join(OUTPUT_DIR, "zone_pollution_timeseries.csv"),
    index=False
)

logging.info("Zone pollution computed (optimized)")

# ==========================================================
# STEP 8: SAVE STATION DATA
# ==========================================================
print("[STEP 8] Saving processed station data...")

stations_gdf.to_crs(epsg=4326).drop(columns="geometry").to_csv(
    os.path.join(OUTPUT_DIR, "stations_processed.csv"),
    index=False
)

# ==========================================================
# STEP 9: HIGH-QUALITY VISUALIZATION
# ==========================================================
print("[STEP 9] Generating high-quality visualization...")

try:
    import matplotlib.pyplot as plt

    # Convert back to WGS84 for visualization
    zones_plot = zones.to_crs(epsg=4326)
    stations_plot = stations_gdf.to_crs(epsg=4326)

    # Create high-resolution figure
    plt.figure(figsize=(12, 12), dpi=300)

    # Plot taxi zones (polygon layer)
    zones_plot.plot(
        facecolor="#f0f0f0",     # light gray fill
        edgecolor="black",
        linewidth=0.5,
        alpha=0.7
    )

    # Plot monitoring stations (point layer)
    stations_plot.plot(
        ax=plt.gca(),
        color="red",
        markersize=20,           # bigger points
        edgecolor="black",
        linewidth=0.5,
        alpha=0.9,
        label="Monitoring Stations"
    )

    # Title
    plt.title("NYC Taxi Zones and Air Quality Monitoring Stations", fontsize=14)

    # Remove axis (clean map style)
    plt.axis("off")

    # Add legend
    plt.legend(loc="upper left")

    # Save high-quality image
    output_path = os.path.join(OUTPUT_DIR, "map.png")
    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    logging.info("High-quality map visualization saved")

except Exception as e:
    logging.warning(f"Visualization failed: {e}")


# ==========================================================
# PIPELINE FINISHED
# ==========================================================
print("\nPipeline finished successfully!")
logging.info("Pipeline completed")

